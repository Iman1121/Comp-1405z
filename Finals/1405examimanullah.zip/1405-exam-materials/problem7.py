def coldest_interval(tempratures, days):
    lowest_average = 2000
    for idx, temperature in enumerate(tempratures):
        count = 0
        average = 0
        if(idx >= (days-1)):
            for x in range(days):
                average = average + tempratures[idx-x]
            count += 1
            average = average/days    
        
            
        if(average < lowest_average):
            lowest_average = average
    return lowest_average


